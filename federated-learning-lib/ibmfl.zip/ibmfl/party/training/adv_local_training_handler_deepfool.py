"""
Licensed Materials - Property of IBM
Restricted Materials of IBM
20190891
© Copyright IBM Corp. 2020 All Rights Reserved.
"""
import os
import logging
from ibmfl.party.training.local_training_handler import \
    LocalTrainingHandler
import numpy as np
from ibmfl.model.model_update import ModelUpdate

import tensorflow as tf

from art.estimators.classification import TensorFlowV2Classifier
from tensorflow.keras.models import load_model

from art.attacks.evasion import ProjectedGradientDescent as pgd
from art.attacks.evasion import BasicIterativeMethod as bim
from art.attacks.evasion import CarliniLInfMethod as cw
from art.attacks.evasion import FastGradientMethod as fgsm
from art.attacks.evasion import DeepFool

from numpy import linalg as LA
from datetime import datetime
import pickle
import time

import math 

from sklearn.preprocessing import LabelBinarizer

np.random.seed(2)

start_time = time.time()

logger = logging.getLogger(__name__)


class AdvLocalTrainingHandlerDeepFool(LocalTrainingHandler):
    # Question how to get model from ART wrapper
    def __init__(self, fl_model, data_handler, hyperparams=None, evidencia=None, **kwargs):
        """
        Initialize LocalTrainingHandler with fl_model, data_handler

        :param fl_model: model to be trained
        :type fl_model: `model.FLModel`
        :param data_handler: data handler that will be used to obtain data
        :type data_handler: `DataHandler`
        :param hyperparams: Hyperparameters used for training.
        :type hyperparams: `dict`
        :param evidencia: evidencia to use
        :type evidencia: `evidencia.EvidenceRecorder`
        :param kwargs: Additional arguments to initialize a local training \
        handler, e.g., a crypto library object to help with encryption and \
        decryption.
        :type kwargs: `dict`
        :return None
        """
        # TensorFlowFLModel or KerasFLModel are not callable. 
        super().__init__(fl_model, data_handler, hyperparams, evidencia,  **kwargs)
            
        # Might use for identify the dataset
        # self.dataset_name = None
        #Change into keras

        logger.info('Initialize a IBM ART class called TensorFlowV2Classifier from IBM FL class \
            named TensorFlowFLModel...')

        self.art_model = TensorFlowV2Classifier(model=self.fl_model, \
                                                nb_classes= 10, \
                                                input_shape=(28, 28, 1), \
                                                loss_object=tf.keras.losses.CategoricalCrossentropy(from_logits=True), \
                                                clip_values=(0, 1), 
                                                channels_first=False)



        # if self.data_handler.file_name is not None:
        #     self.dataset_name = self.data_handler.file_name
        #     #Add batch 
    
        # self.info = info

        # # Load the batch size if any
        # if self.info is not None:
        #     if 'batch_size' in self.info:
        #         self.batch_size = self.info.get('batch_size')

        # if info is not None:
            # self.alpha = info.setdefault("alpha", 0)
            # Load the provided parameter from the config file, info 

        logger.info('Finished creating a new AdvLocalTrainingHandler object.') 
    
        
    def create_malicous_dataset(self, attack_params=None, num_adv_imgs=320, bs=32):
        ''' return: an appropriate data format object
        args: 
            image_list: a list of numpy arrays of training images
            label_list:a list of binarized labels for each image
            num_client: number of fedrated members (clients)
            initials: the clients'name prefix, e.g, clients_1 
        '''
        
        (_), (x_test, y_test) = self.data_handler.get_data()

        attack = DeepFool(self.art_model, max_iter=20)

        adv = x_test[0:num_adv_imgs]

        # print(type(adv))

        x_test_pgd = attack.generate(adv)

        y_test_pgd = y_test[0:num_adv_imgs]


        return (x_test_pgd, y_test_pgd)

    def train(self,  fit_params=None):
        """
        Train locally using fl_model. At the end of training, a
        model_update with the new model information is generated and
        send through the connection.

        :param fit_params: (optional) Query instruction from aggregator
        :type fit_params: `dict`
        :return: ModelUpdate
        :rtype: `ModelUpdate`
        """
        label_as_binary = LabelBinarizer()
        

        (x_train, y_train), (_) = self.data_handler.get_data()

        y_train = label_as_binary.fit_transform(y_train)
        
        logger.info('x_train=' + str(x_train.shape))
        logger.info('y_train=' + str(y_train.shape))

        # self.update_model(fit_params('model_update'))

        # logger.info('Wrap tensorflow model with art model...')

        # #Assume CIFAR-10
        # self.art_model = TensorFlowV2Classifier(model=self.fl_model, \
        #                                         nb_classes= 10, \
        #                                         input_shape=(28, 28, 1), \
        #                                         loss_object=tf.keras.losses.CategoricalCrossentropy(from_logits=True), \
        #                                         clip_values=(0, 1), 
        #                                         channels_first=False)

        logger.info('Generate adversarial examples...')

        (x_test_pgd, y_test_pgd) = self.create_malicous_dataset(num_adv_imgs=100, bs=32)

        y_test_pgd = label_as_binary.fit_transform(y_test_pgd)

        logger.info('y_test_pgd=' + str(y_test_pgd.shape))

        # Adversarial traininng
        
        x_train_adv = np.append(x_test_pgd, x_train, axis=0) # store the generated adversarial examples at each iteration
        y_train_adv = np.append(y_test_pgd, y_train, axis=0)

       
        # print('x_train_adv.shape ' , x_train_adv.shape )
        # print('x_train_adv.shape ' , x_train_adv.shape )
        
        # Retrain the classifier
        logger.info('Model training started...')

        # self.fl_model.fit_model((x_train_adv, y_train_adv), fit_params, local_params=self.hyperparams)
        # self.fl_model.fit_model((x_train, y_train), fit_params, local_params=self.hyperparams)
        self.fl_model.fit(x_train_adv, y_train_adv)

        w = self.fl_model.get_weights()

        update = ModelUpdate(weights=w)

        _train_count = x_train.shape[0]
        
        update.add('train_counts', _train_count)

        logger.info('Adversarial local training done, generating model update...')

        self.get_train_metrics_post()

        return update

    def save_local_model(self, filename=None):
        """Save local model 
        """
        saved_file = None
        if self.fl_model:
            saved_file = self.fl_model.save_model(filename=filename)

        return saved_file

    



